# Models

The trained model artifact is generated automatically by:

```bash
python src/train.py
```

The generated file is:

```text
models/churn_pipeline.joblib
```

Model artifacts are ignored by Git because binary model files can become large and are better managed separately when required.
