"""Tests for the Week 3 customer churn ML pipeline."""

import pandas as pd
import pytest

from src.train import (
    build_models,
    build_preprocessor,
    prepare_data,
    validate_dataset,
)


def test_target_column_is_required():
    """Validation should fail when Churn is missing."""

    df = pd.DataFrame(
        {
            "tenure": [1, 2],
        }
    )

    with pytest.raises(ValueError):
        validate_dataset(df)


def test_unexpected_target_labels_are_rejected():
    """Validation should reject labels other than Yes/No."""

    df = pd.DataFrame(
        {
            "Churn": [
                "Yes",
                "Maybe",
            ]
        }
    )

    with pytest.raises(ValueError):
        validate_dataset(df)


def test_target_is_binary_after_preparation():
    """Churn should be converted to integer 0/1."""

    df = pd.DataFrame(
        {
            "customerID": [
                "A",
                "B",
            ],
            "tenure": [
                1,
                12,
            ],
            "TotalCharges": [
                "10.5",
                "200.0",
            ],
            "Churn": [
                "No",
                "Yes",
            ],
        }
    )

    X, y = prepare_data(df)

    assert set(y.unique()) <= {0, 1}
    assert y.dtype.kind in {"i", "u"}


def test_identifier_is_not_used_as_feature():
    """customerID should be removed before training."""

    df = pd.DataFrame(
        {
            "customerID": [
                "A",
                "B",
            ],
            "tenure": [
                1,
                12,
            ],
            "TotalCharges": [
                "10.5",
                "200.0",
            ],
            "Churn": [
                "No",
                "Yes",
            ],
        }
    )

    X, _ = prepare_data(df)

    assert "customerID" not in X.columns
    assert "Churn" not in X.columns


def test_invalid_target_conversion_is_rejected():
    """Unexpected target values should fail safely."""

    df = pd.DataFrame(
        {
            "tenure": [1],
            "TotalCharges": ["10"],
            "Churn": ["Unknown"],
        }
    )

    with pytest.raises(ValueError):
        prepare_data(df)


def test_preprocessor_can_be_built():
    """The preprocessing transformer should construct successfully."""

    X = pd.DataFrame(
        {
            "tenure": [1, 12],
            "MonthlyCharges": [30.0, 80.0],
            "Contract": [
                "Month-to-month",
                "One year",
            ],
        }
    )

    preprocessor = build_preprocessor(X)

    assert preprocessor is not None
    assert len(preprocessor.transformers) == 2


def test_models_are_created():
    """Both planned model candidates should be available."""

    X = pd.DataFrame(
        {
            "tenure": [1, 12],
            "MonthlyCharges": [30.0, 80.0],
            "Contract": [
                "Month-to-month",
                "One year",
            ],
        }
    )

    preprocessor = build_preprocessor(X)
    models = build_models(preprocessor)

    assert "logistic_regression" in models
    assert "random_forest" in models


def test_small_pipeline_can_fit_and_predict():
    """The Random Forest pipeline should fit a small synthetic dataset."""

    X = pd.DataFrame(
        {
            "tenure": [
                1, 2, 3, 12, 24, 36,
            ],
            "MonthlyCharges": [
                90, 85, 95, 70, 60, 55,
            ],
            "Contract": [
                "Month-to-month",
                "Month-to-month",
                "Month-to-month",
                "One year",
                "Two year",
                "Two year",
            ],
        }
    )

    y = pd.Series(
        [
            1, 1, 1,
            0, 0, 0,
        ]
    )

    preprocessor = build_preprocessor(X)
    models = build_models(preprocessor)

    model = models["random_forest"]
    model.fit(X, y)

    predictions = model.predict(X)
    probabilities = model.predict_proba(X)[:, 1]

    assert len(predictions) == len(X)
    assert len(probabilities) == len(X)
    assert ((probabilities >= 0) & (probabilities <= 1)).all()
