"""
Week 3 - Customer Churn Model Training

This module implements a reproducible machine-learning workflow for
binary customer churn prediction.

Workflow:
    1. Load and validate data
    2. Prepare features and target
    3. Split data using stratification
    4. Build preprocessing pipelines
    5. Compare Logistic Regression and Random Forest
    6. Evaluate the selected model
    7. Save the complete preprocessing + model pipeline
"""

from pathlib import Path

import joblib
import pandas as pd

from sklearn.compose import ColumnTransformer
from sklearn.ensemble import RandomForestClassifier
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    accuracy_score,
    classification_report,
    confusion_matrix,
    f1_score,
    precision_score,
    recall_score,
    roc_auc_score,
)
from sklearn.model_selection import (
    StratifiedKFold,
    cross_val_score,
    train_test_split,
)
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler


# ---------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------

RANDOM_STATE = 42
TEST_SIZE = 0.20
CV_FOLDS = 5

DATA_PATH = Path(
    "data/raw/WA_Fn-UseC_-Telco-Customer-Churn.csv"
)

MODEL_DIR = Path("models")
MODEL_PATH = MODEL_DIR / "churn_pipeline.joblib"


# ---------------------------------------------------------------------
# Data validation
# ---------------------------------------------------------------------

def validate_dataset(df: pd.DataFrame) -> None:
    """Validate basic requirements before model training.

    Raises:
        ValueError: If the dataset is empty, the target is missing,
            or unexpected target labels are found.
    """

    if df.empty:
        raise ValueError("Dataset is empty.")

    if "Churn" not in df.columns:
        raise ValueError(
            "Required target column 'Churn' is missing."
        )

    labels = set(df["Churn"].dropna().unique())

    if not labels.issubset({"Yes", "No"}):
        raise ValueError(
            f"Unexpected Churn labels found: {labels}"
        )

    duplicate_count = int(df.duplicated().sum())

    if duplicate_count:
        print(
            f"Warning: {duplicate_count} duplicate rows detected."
        )

    print(f"Dataset shape: {df.shape}")
    print("\nTarget distribution:")
    print(df["Churn"].value_counts())


# ---------------------------------------------------------------------
# Data preparation
# ---------------------------------------------------------------------

def prepare_data(df: pd.DataFrame):
    """Clean known fields and separate features from target.

    Args:
        df: Raw customer churn DataFrame.

    Returns:
        X: Feature DataFrame.
        y: Binary target Series.
    """

    df = df.copy()

    # The public dataset may contain blank strings in TotalCharges.
    # Converting invalid values to NaN allows the preprocessing
    # pipeline to handle them using median imputation.
    df["TotalCharges"] = pd.to_numeric(
        df["TotalCharges"],
        errors="coerce",
    )

    # customerID is an identifier rather than a meaningful
    # predictive feature. Keeping it could introduce noise
    # and reduce model generalization.
    df = df.drop(
        columns=["customerID"],
        errors="ignore",
    )

    # Convert the target from text labels to binary values.
    y = df["Churn"].map(
        {
            "No": 0,
            "Yes": 1,
        }
    )

    if y.isna().any():
        raise ValueError(
            "Target conversion produced missing labels."
        )

    X = df.drop(columns=["Churn"])

    return X, y.astype(int)


# ---------------------------------------------------------------------
# Preprocessing
# ---------------------------------------------------------------------

def build_preprocessor(X: pd.DataFrame) -> ColumnTransformer:
    """Create a reusable and leakage-safe preprocessing transformer."""

    numeric_features = X.select_dtypes(
        include=[
            "int64",
            "float64",
            "int32",
            "float32",
        ]
    ).columns.tolist()

    categorical_features = X.select_dtypes(
        include=[
            "object",
            "category",
            "bool",
        ]
    ).columns.tolist()

    numeric_pipeline = Pipeline(
        steps=[
            (
                "imputer",
                SimpleImputer(strategy="median"),
            ),
            (
                "scaler",
                StandardScaler(),
            ),
        ]
    )

    categorical_pipeline = Pipeline(
        steps=[
            (
                "imputer",
                SimpleImputer(
                    strategy="most_frequent"
                ),
            ),
            (
                "onehot",
                OneHotEncoder(
                    handle_unknown="ignore",
                    sparse_output=False,
                ),
            ),
        ]
    )

    return ColumnTransformer(
        transformers=[
            (
                "num",
                numeric_pipeline,
                numeric_features,
            ),
            (
                "cat",
                categorical_pipeline,
                categorical_features,
            ),
        ],
        remainder="drop",
    )


# ---------------------------------------------------------------------
# Model construction
# ---------------------------------------------------------------------

def build_models(preprocessor):
    """Build baseline and candidate model pipelines."""

    logistic_model = Pipeline(
        steps=[
            (
                "preprocessor",
                preprocessor,
            ),
            (
                "classifier",
                LogisticRegression(
                    max_iter=1000,
                    class_weight="balanced",
                    random_state=RANDOM_STATE,
                ),
            ),
        ]
    )

    random_forest_model = Pipeline(
        steps=[
            (
                "preprocessor",
                preprocessor,
            ),
            (
                "classifier",
                RandomForestClassifier(
                    n_estimators=300,
                    min_samples_split=4,
                    min_samples_leaf=2,
                    class_weight="balanced",
                    random_state=RANDOM_STATE,
                    n_jobs=-1,
                ),
            ),
        ]
    )

    return {
        "logistic_regression": logistic_model,
        "random_forest": random_forest_model,
    }


# ---------------------------------------------------------------------
# Cross-validation
# ---------------------------------------------------------------------

def compare_models(
    models,
    X_train,
    y_train,
) -> pd.DataFrame:
    """Compare models using stratified cross-validation.

    ROC-AUC is used here because it evaluates how well the model
    ranks positive and negative examples across probability thresholds.
    """

    cv = StratifiedKFold(
        n_splits=CV_FOLDS,
        shuffle=True,
        random_state=RANDOM_STATE,
    )

    results = []

    for name, model in models.items():
        scores = cross_val_score(
            model,
            X_train,
            y_train,
            cv=cv,
            scoring="roc_auc",
            n_jobs=-1,
        )

        results.append(
            {
                "model": name,
                "cv_roc_auc_mean": scores.mean(),
                "cv_roc_auc_std": scores.std(),
            }
        )

    return (
        pd.DataFrame(results)
        .sort_values(
            "cv_roc_auc_mean",
            ascending=False,
        )
        .reset_index(drop=True)
    )


# ---------------------------------------------------------------------
# Final evaluation
# ---------------------------------------------------------------------

def evaluate_model(
    model,
    X_train,
    X_test,
    y_train,
    y_test,
):
    """Fit a model and calculate classification metrics."""

    model.fit(
        X_train,
        y_train,
    )

    predictions = model.predict(X_test)

    probabilities = model.predict_proba(
        X_test
    )[:, 1]

    metrics = {
        "accuracy": accuracy_score(
            y_test,
            predictions,
        ),
        "precision": precision_score(
            y_test,
            predictions,
            zero_division=0,
        ),
        "recall": recall_score(
            y_test,
            predictions,
            zero_division=0,
        ),
        "f1": f1_score(
            y_test,
            predictions,
            zero_division=0,
        ),
        "roc_auc": roc_auc_score(
            y_test,
            probabilities,
        ),
    }

    print("\nClassification Report")
    print("-" * 60)

    print(
        classification_report(
            y_test,
            predictions,
            zero_division=0,
        )
    )

    print("Confusion Matrix")
    print("-" * 60)
    print(
        confusion_matrix(
            y_test,
            predictions,
        )
    )

    return metrics, model


# ---------------------------------------------------------------------
# Main training workflow
# ---------------------------------------------------------------------

def main():
    """Execute the complete model-training workflow."""

    if not DATA_PATH.exists():
        raise FileNotFoundError(
            "Dataset not found.\n"
            f"Expected location: {DATA_PATH.resolve()}\n"
            "Place the IBM Telco Customer Churn CSV file "
            "inside data/raw/."
        )

    print("Loading dataset...")
    df = pd.read_csv(DATA_PATH)

    print("Validating dataset...")
    validate_dataset(df)

    print("\nPreparing features and target...")
    X, y = prepare_data(df)

    print("\nCreating stratified train/test split...")
    (
        X_train,
        X_test,
        y_train,
        y_test,
    ) = train_test_split(
        X,
        y,
        test_size=TEST_SIZE,
        stratify=y,
        random_state=RANDOM_STATE,
    )

    print("\nBuilding preprocessing pipeline...")
    preprocessor = build_preprocessor(
        X_train
    )

    print("Building candidate models...")
    models = build_models(
        preprocessor
    )

    print("\nRunning cross-validation...")
    comparison = compare_models(
        models,
        X_train,
        y_train,
    )

    print("\nCross-validation comparison")
    print("-" * 60)
    print(
        comparison.to_string(
            index=False
        )
    )

    # The model is selected from validation evidence rather
    # than from a manually assumed accuracy.
    selected_name = comparison.iloc[0][
        "model"
    ]

    selected_model = models[
        selected_name
    ]

    print(
        f"\nSelected candidate: {selected_name}"
    )

    print(
        "\nEvaluating on untouched test set..."
    )

    test_metrics, selected_model = (
        evaluate_model(
            selected_model,
            X_train,
            X_test,
            y_train,
            y_test,
        )
    )

    print("\nHeld-out test metrics")
    print("-" * 60)

    for metric, value in test_metrics.items():
        print(
            f"{metric:10s}: {value:.4f}"
        )

    # Save the complete pipeline so that the same
    # preprocessing steps are automatically applied
    # during future inference.
    MODEL_DIR.mkdir(
        parents=True,
        exist_ok=True,
    )

    joblib.dump(
        selected_model,
        MODEL_PATH,
    )

    print(
        f"\nSaved model pipeline to: "
        f"{MODEL_PATH.resolve()}"
    )


if __name__ == "__main__":
    main()
