# Dataset

Place the public IBM Telco Customer Churn CSV file in this directory:

```text
data/raw/WA_Fn-UseC_-Telco-Customer-Churn.csv
```

The dataset is intentionally excluded from Git tracking by `.gitignore`.

Do not commit private, confidential or personally identifiable customer data.
